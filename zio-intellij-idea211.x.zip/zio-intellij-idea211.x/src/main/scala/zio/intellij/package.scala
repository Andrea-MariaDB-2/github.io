package zio

import com.intellij.openapi.util.IconLoader.getIcon
import javax.swing.Icon

package object intellij {
  val ZioIcon: Icon = getIcon("/images/zio-full-color-rgb.svg", getClass)
}
