package zio.intellij.synthetic.macros

class ModulePatternAccessibleM extends ModulePatternAccessibleMBase {
  override protected val macroName: String        = "zio.macros.accessibleM"
  override protected val expectedTypeParams: Long = 1
}
