package zio.intellij.synthetic.macros

class ModulePatternAccessibleMM extends ModulePatternAccessibleMBase {
  override protected val macroName: String        = "zio.macros.accessibleMM"
  override protected val expectedTypeParams: Long = 2
}
