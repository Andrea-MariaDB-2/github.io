package zio.intellij

import javax.swing.Icon

package object gutter {
  val fiberIcon: Icon = com.intellij.icons.AllIcons.Debugger.Threads
}
