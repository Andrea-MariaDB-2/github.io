module.exports = {
  Learn: [
    'learn/get-started',
    'learn/what-is-tezos',
    'learn/store-and-use',
    'learn/bake',
    'learn/activate'
  ]
};
