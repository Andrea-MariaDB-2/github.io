# The Attic

This folder holds prior versions of docusaurus components so that any customization could be compared against newer versions, and applied differently.

This same purpose could be achieved with git, but the last known correct version is easily found in the attic.

