import React from 'react'
import CampPage from 'components/campaign/CampPage'

const Discover = () => <CampPage campaign="discover" />

export default Discover