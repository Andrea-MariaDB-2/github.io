import React from 'react'
import SignUp from 'components/campaign/SignUp'

const DiscSignUp = ({ history }) => <SignUp campaign="discover" history={history}/>

export default DiscSignUp