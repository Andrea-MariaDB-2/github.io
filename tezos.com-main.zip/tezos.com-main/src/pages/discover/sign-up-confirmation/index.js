import React from 'react'
import SignUpConfirm from 'components/campaign/SignUpConfirm'

const ConfirmDiscover = () => <SignUpConfirm campaign="discover" />

export default ConfirmDiscover