import React from 'react'
import SignUpConfirm from 'components/campaign/SignUpConfirm'

const HelloConfirm = () => <SignUpConfirm campaign="hello-world" />

export default HelloConfirm