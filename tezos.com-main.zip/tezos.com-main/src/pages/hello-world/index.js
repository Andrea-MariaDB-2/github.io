import React from 'react'
import CampPage from 'components/campaign/CampPage'

const HelloWorld = () => <CampPage campaign="hello-world" />

export default HelloWorld