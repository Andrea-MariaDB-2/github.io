import React from 'react'
import SignUp from 'components/campaign/SignUp'

const HelloSignUp = ({ history }) => <SignUp campaign="hello-world" history={history}/>

export default HelloSignUp