---
id: resources
title: Resources
sidebar_label: Resources
---

#### Connect (module)

Connect because:
* reason 1 lorem
* reason 2 lorem
* reason 3 lorem

Send an email to reachout@tezos.com

#### Resources (module)

* File Lorem Ipsum (for press) download ZIP |  PDF 
* File Lorem Ipsum (for creatives / developers) download ZIP |  PDF
* File Lorem Ipsum download ZIP |  PDF 

#### FAQs (module)
* 3-4 questions and answers about Tezos (answers to frequent questions submitted via email)