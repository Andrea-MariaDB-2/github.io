---
id: developer-tools
title: Developer Tools
sidebar_label: Developer Tools
---

##### Core Infrastructure (module)
Intro

###### Grouping Name
Intro
* item 1
* item 2
* item 3

Repeat for 2-3 grouping of the 'Core Infrastructure' links listed on current dev portal https://developers.tezos.com/

##### Tools (module)
Intro

###### Tool Grouping Name
* Tool title and description 1
* Tool title and description 2
* etc

Repeat for 2-3 grouping of the 'Tools' listed on current dev portal https://developers.tezos.com/

##### Training & Education (module)
Intro

###### Training & Education Grouping Name
* Training & Education title and description 1
* Training & Education title and description 2
* etc

Repeat for 3-6 grouping of the 'Online Training Courses and Educational Resources' listed on current dev portal https://developers.tezos.com/