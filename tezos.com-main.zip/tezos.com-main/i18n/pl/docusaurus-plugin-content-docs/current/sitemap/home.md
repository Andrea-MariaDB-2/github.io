---
id: home
title: Home
sidebar_label: Home
---

*Note: This page is intended merely to document the modules meant for the homepage.*

Tezos: Digital Money

Empowering lorem

#### Newsletter Signup (module)
Why sign up?
Email
Submit
Thanks for signing up
Error message

#### Twitter (module)
Follow Tezos > link to [Twitter](https://twitter.com/tezos "Twitter")

#### What is Tezos and Value Prop (module)
* Learn more about Tezos > Link to [Tezos Overview](tezos-overview/)

#### New to Tezos? (module)
* Why it matters to you (RTB)? > Link to [Tez](tez/)
* Talk about the value of the Tezos ecosystem (community, innovation, diversity)

#### Why have Tez? (module)
* Why Have Tez?
* Learn more about > Link to [Tez](tez/)

#### Start Developing / Building on Tezos? (module)
* Link to [Get Started](get-started/)
* Link to [Developer Tools](developer-tools/) 

#### In the Ecosystem (module)
* (Events, Podcasts, Classes)
Link to [Events](events/)