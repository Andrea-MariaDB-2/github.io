---
id: tez
title: Tez
sidebar_label: Tez
---

#### What is Tez Value Prop (module)
* Tez vs. Tezos: What is the difference?
* What does tez do?
* What is unique about it and why does it matter?
* How is it different “normal” money (and a little on how its different than other tokens) 

Having tez gives you:
* governance + incentive alignment + participation
* secure network
* earn rewards and fight inflations (staking - soft touch)

#### Wallets (module)
* What is a Wallet? 
* Lorem ipsum categories: software, hardware and command line.
* Options for non-exclusive Tezos  wallets (coinbase etc). 
* Link to [Wiki](https://wiki.tezosagora.org/learn/resources/wallets "Wiki")

#### Accessing Tez (module)
* How can I hold, store and use tez?
* Link to decentralized marketplace > 
* Link to centralized marketplace > 

#### What Can Be Done With Tez? (module)
* Hypthetical Examples
* he next generation built to power games, apps
* Tez gets you....(enables you to) - make it consumer app relevant (creator economy, gaming, identity)
* Link to Wallets > [Wiki](https://wiki.tezosagora.org/learn/resources/wallets "Wiki")
* Link to Centralized or Decentralized Exchange > 

#### FAQs (module)
* 2-3 questions and answers about Tez