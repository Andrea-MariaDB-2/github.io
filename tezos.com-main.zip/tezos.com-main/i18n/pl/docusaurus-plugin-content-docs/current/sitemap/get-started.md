---
id: get-started
title: Get Started
sidebar_label: Get Started
---

#### Welcome Developers (module)
* What is the USP for a new developer to blockchain
* What is the USP for a developer seasoned on crypto (most likely Ethereum) 

#### Onboarding - Devs (module)
Steps for new Dev
* Read documentation Lorem Ipsum (Link to [Gitlab](https://gitlab.com/tezos/tezos 'Gitlab'), Link to [Wiki](https://wiki.tezosagora.org/ 'Wiki'))
* Take a course Lorem ipsum (Link to  [Developer Tools](https://tezos.com/build/developer-tools "Developer"))
* Connect in the ecosystem  (Link to [Resources](https://tezos.com/ecosystem/resources "Resources"))
* Find a mentor Lorem ipsum ([Agora](https://agora.tezos.com/learn "Agora")

Getting Up and Running
As a new dev. this is how you get started: 
* Get your first “Hello World” 
* Write a Smart Contract 
* Use a Library - Explore the blockain

Tools / Steps Critical to Transitioning into to Tezos
As a “transitioning” dev. lorem ipsum:
* Lorem Ipsum 
* Lorem Ipsum - Lorem Ipsum 