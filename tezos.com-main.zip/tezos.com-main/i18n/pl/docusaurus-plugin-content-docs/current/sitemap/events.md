---
id: events
title: Events
sidebar_label: Events
---

###### Event List  (module)
* event series / event name
* date (optional)
* topic/theme
* location ('online' for now)
* format (podcast, webinar)
* short description
* Link to website with more details

Repeat for each event series to be listed (e.g. TQuorum Sessions, Nomadic Labs Research Seminars, Tezos Commons TezTalks)