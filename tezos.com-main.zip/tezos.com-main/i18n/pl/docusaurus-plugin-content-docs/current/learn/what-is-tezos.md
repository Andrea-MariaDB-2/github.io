---
id: what-is-tezos
title: atwhay isyay ezostay?
sidebar_label: atwhay isyay ezostay?
---

## ethay asicsbay

ezostay isyay anyay open-sourceyay atformplay orfay assetsyay andyay applicationsyay atthay ancay evolveyay ybay upgradingyay itselfyay. akeholdersstay overngay upgradesyay otay ethay orecay otocolpray , includingyay upgradesyay otay ethay amendmentyay ocesspray itselfyay.

### elf-amendmentsay

elf-amendmentsay allowsyay ezostay otay upgradeyay itselfyay ithoutway avinghay otay itsplay (“fork”) ethay etworknay intoyay otway ifferentday ockchainsblay . isthay isyay importantyay asyay ethay uggestionsay oryay expectationyay ofyay ayay orkfay ancay ivideday ethay ommunitycay , alteryay akeholderstay incentivesyay , andyay isruptday ethay etworknay effectsyay atthay areyay ormedfay overyay imetay . ecausebay ofyay elf-amendmentsay , oordinationcay andyay executionyay ostscay orfay otocolpray upgradesyay areyay educedray andyay uturefay innovationsyay ancay ebay eamlesslysay implementedyay . 

### on-chainyay overnancegay

inyay ezostay , allyay akeholdersstay ancay articipatepay inyay overninggay ethay otocolpray . ethay electionyay ecyclay ovidespray ayay ormalfay andyay ematicsystay ocedurepray orfay akeholdersstay otay eachray agreementyay onyay oposedpray otocolpray amendmentsyay . ybay ombiningcay isthay on-chainyay echanismmay ithway elf-amendmentsay , ezostay ancay angechay isthay initialyay electionyay ocesspray otay adoptyay etterbay overnancegay echanismsmay enwhay eythay areyay iscoveredday . 

### ecentralizedday innovationyay

oposedpray amendmentsyay atthay areyay acceptedyay ybay akeholdersstay ancay includeyay aymentpay otay individualsyay oryay oupsgray atthay improveyay ethay otocolpray . isthay undingfay echanismmay encouragesyay obustray articipationpay andyay ecentralizesday ethay aintenancemay ofyay ethay etworknay . osteringfay anyay activeyay , openyay , andyay iverseday eveloperday ecosystemyay atthay isyay incentivizedyay otay ontributecay otay ethay otocolpray illway acilitatefay ezostay evelopmentday andyay adoptionyay . 

### artsmay ontractscay & ormalfay erificationvay

ezostay offersyay ayay atformplay otay eatecray artsmay ontractscay andyay uildbay ecentralizedday applicationsyay atthay annotcay ebay ensoredcay oryay ut-downshay ybay irdthay artiespay . urthermorefay , ezostay acilitatesfay ormalfay erificationvay , ayay echniquetay usedyay otay improveyay ecuritysay ybay athematicallymay ovingpray opertiespray aboutyay ogramspray uchsay asyay artsmay ontractscay . isthay echniquetay , ifyay usedyay operlypray , ancay elphay avoidyay ostlycay ugsbay andyay ethay ontentiouscay ebatesday atthay ollowfay . 

### oof-of-stakepray (pos)

articipantspay (“nodes”) inyay ecentralizedday , eer-to-peerpay etworksnay ovidepray ethay ecessarynay omputationalcay esourcesray atthay eepkay ayay etworknay upyay andyay unningray . oof-of-stakepray (pos) isyay ethay echanismmay ybay ichwhay ethay ariousvay articipantspay inyay ezostay eachray onsensuscay onyay ethay atestay ofyay ethay ockchainblay . unlikeyay otheryay ospay otocolspray , anyyay akeholderstay ancay articipatepay inyay ethay onsensuscay ocesspray inyay ezostay andyay ebay ewardedray ybay ethay otocolpray itselfyay orfay ontributingcay otay ethay ecuritysay andyay abilitystay ofyay ethay etworknay . additionallyyay , ospay isyay esslay ostlycay anthay otheryay onsensuscay echanismsmay andyay owerslay ethay arriersbay otay entryyay orfay involvementyay . 

### elegationday

inyay ospay , ayay ecuritysay epositday isyay equiredray otay articipatepay inyay ethay onsensuscay ocesspray andyay avoidyay eingbay ilutedday ybay inflationyay . asyay inyay oof-of-workpray , ethay onsensuscay otocolpray eliesray onyay anyay onesthay ajoritymay orfay itsyay ecuritysay ichwhay isyay incentivizedyay irectlyday ybay ethay ezostay otocolpray ybay enalizingpay ishonestday ehaviorbay andyay ewardingray onesthay ehaviorbay . ifyay ayay articipantpay ehavesbay ishonestlyday , eythay ancay oselay eirthay epositday . usersyay owhay oday otnay ishway otay articipatepay irectlyday inyay ethay onsensuscay otocolpray avehay ethay optionyay otay elegateday eirthay ightsray otay otheryay usersyay otay articipatepay onyay eirthay ehalfbay . 


## esourcesray

 - [ezostay itewhay aperpay](https://tezos.com/whitepaper.pdf)
 - [ezostay useyay asescay](https://wiki.tezosagora.org/learn/uses-of-tezos)
 - [Tezos Consensus Algorithm](https://wiki.tezosagora.org/learn/baking/proofofstake)
 - [ezostay onsensuscay algorithmyay](https://tezos.com/position-paper.pdf)