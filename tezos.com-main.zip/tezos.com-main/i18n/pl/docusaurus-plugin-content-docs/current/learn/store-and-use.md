---
id: store-and-use
title: orestay & useyay
sidebar_label: orestay & useyay
---

## ethay asicsbay

oldinghay ezostay okenstay (“tez”) enablesyay oneyay otay interactyay ithway ethay ezostay ockchainblay . erethay areyay anymay alletsway ithway ichwhay otay orestay andyay useyay eztay . alletsway istedlay elowbay avehay undergoneyay atyay eastlay oneyay independentyay externalyay ecuritysay audityay . 

alwaysyay ememberray: **ifyay ouyay oday otnay ontrolcay ouryay ivatepray eyskay , ouyay oday otnay ontrolcay ouryay okenstay**. everyyay useryay ouldshay akemay uresay otay exerciseyay extremeyay arecay andyay aketay allyay availableyay afetysay ecautionspray enwhay enteringyay ivatepray eykay informationyay anywhereyay . anyyay artypay oryay oftwaresay , uchsay asyay ayay alletway , atthay ainsgay owledgeknay ofyay ivatepray eykay informationyay illway avehay accessyay otay ethay eztay ontrolledcay ybay ethay orrespondingcay ublicpay eykay ashhay . 

**otenay: ontributorscay otay ethay ezostay foundation’s undraiserfay ancay etgay artedstay iavay ethay activateyay abtay**

## alletsway

### oftwaresay alletsway

- [AirGap](https://airgap.it/ "Airgap")<sup>†</sup> *(iOS, Android, Web)*
- [Galleon Wallet](https://cryptonomic.tech/galleon.html "Galleon Wallet") *(macOS, Windows, Linux)*
- [Kukai](https://wallet.kukai.app/ "Kukai") *(Web)*
- [Magma](https://magmawallet.io/ "Magma")<sup>†</sup> *(iOS, Android)*
- ZenGo<sup>†</sup>  *(iOS, Android)*
- [Guarda](https://guarda.com/ "Guarda")<sup>†</sup> *(macOS, Windows, iOS, Android)*

### ardwarehay alletsway

- [Ledger](https://www.ledger.com/ "Ledger") *(Obsidian Systems)*
- [Trezor](https://trezor.io/ "Trezor")

### ommandcay inelay
- [Tezos CLI](https://tezos.gitlab.io/shell/cli-commands.html "Tezos CLI")

<br />
<br />

<sup>*</sup> esethay inkslay orfay alletsway areyay eingbay ovidedpray asyay ayay onveniencecay andyay orfay informationalyay urposespay only; eythay oday otnay onstitutecay anyay endorsementyay oryay anyay approvalyay ybay ethay ezostay oundationfay ofyay anyyay ofyay ethay oductspray oryay ervicessay ovidedpray ybay osethay itessay . ethay ezostay oundationfay earsbay onay esponsibilityray orfay ethay accuracyyay , egalitylay oryay ontentcay ofyay ethay externalyay itessay oryay orfay atthay ofyay ubsequentsay inkslay , oryay orfay ethay erformancepay oryay acklay ereofthay ofyay anyyay alletsway ovidedpray ybay osethay itessay . ontactcay ethay externalyay itesay orfay answersyay otay uestionsqay egardingray itsyay ontentcay . 
<br />
<br />
<sup>†</sup> oesday otnay upportsay ethay importingyay ofyay ayay undraiserfay accountyay . 