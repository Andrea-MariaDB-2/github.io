export const isWindows = (): boolean => navigator.appVersion.includes('Windows');
