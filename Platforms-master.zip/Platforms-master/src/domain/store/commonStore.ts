export interface CommonStore {
    loading: boolean;
}
